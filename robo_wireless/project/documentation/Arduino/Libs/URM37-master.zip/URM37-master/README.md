This is a library for communication with URM37 ultrasound sensor by
Yerobot/DFRobot.

This is a fork of the library by Miles Burton with changes that allow
it to be compiled with Arduino Software version 1.x.
